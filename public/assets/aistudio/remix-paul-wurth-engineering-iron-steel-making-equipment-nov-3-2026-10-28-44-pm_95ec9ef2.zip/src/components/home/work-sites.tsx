export function WorkSites() {
  return (
    <section className="work-sites" aria-labelledby="work-sites-title">
      <div className="work-sites-heading">
        <p className="eyebrow">
          <span></span>OUR PEOPLE / IN THE FIELD
        </p>
        <div>
          <h2 id="work-sites-title">Engineering at work.</h2>
          <p>
            From the drawing board to the work site, our people bring experience and teamwork to the construction and modernization of industrial equipment.
          </p>
        </div>
      </div>
      <div className="work-sites-images">
        <figure>
          <img
            src="https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/b5f95daf-ed4a-4584-a54f-3bf767090087.png"
            srcSet="https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/b5f95daf-ed4a-4584-a54f-3bf767090087.png?width=375 375w, https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/b5f95daf-ed4a-4584-a54f-3bf767090087.png?width=768 768w, https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/b5f95daf-ed4a-4584-a54f-3bf767090087.png?width=1024 1024w, https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/b5f95daf-ed4a-4584-a54f-3bf767090087.png 1280w"
            sizes="(min-width: 761px) 50vw, 100vw"
            alt="Illustrative image of engineers reviewing plans at an industrial work site"
            loading="lazy"
          />
          <figcaption>Collaboration on site</figcaption>
        </figure>
        <figure>
          <img
            src="https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/6b069342-1a02-4711-836f-baea477ea708.png"
            srcSet="https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/6b069342-1a02-4711-836f-baea477ea708.png?width=375 375w, https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/6b069342-1a02-4711-836f-baea477ea708.png?width=768 768w, https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/6b069342-1a02-4711-836f-baea477ea708.png?width=1024 1024w, https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/6b069342-1a02-4711-836f-baea477ea708.png 1280w"
            sizes="(min-width: 761px) 50vw, 100vw"
            alt="Illustrative image of a worker welding steel at an industrial site"
            loading="lazy"
          />
          <figcaption>Building and modernizing equipment</figcaption>
        </figure>
      </div>
    </section>
  );
}
