import { Link } from 'react-router-dom';
import { PWLogo } from '@/components/pw-logo';

export function Hero() {
  return (
    <section className="company-hero" aria-label="Paul Wurth company introduction">
      <img
        src="https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/9a2e641b-1aab-48fb-922d-967a52f605ce.png"
        srcSet="https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/9a2e641b-1aab-48fb-922d-967a52f605ce.png?width=375 375w, https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/9a2e641b-1aab-48fb-922d-967a52f605ce.png?width=768 768w, https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/9a2e641b-1aab-48fb-922d-967a52f605ce.png?width=1024 1024w, https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/9a2e641b-1aab-48fb-922d-967a52f605ce.png?width=1440 1440w, https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/9a2e641b-1aab-48fb-922d-967a52f605ce.png 1472w"
        sizes="100vw"
        alt="Illustrative view of a modern Luxembourg engineering headquarters under a blue sky"
        loading="eager"
      />
      <div className="company-hero-logo">
        <PWLogo size="lg" />
        <span className="hero-name-logo">
          <b className="wm-blue">Paul</b> <b className="wm-red">Wurth</b>
        </span>
      </div>
      <div className="company-breadcrumb">
        <Link to="/">Paul Wurth S.A.</Link>
        <span>›</span>
        <span>Our company</span>
      </div>
    </section>
  );
}
