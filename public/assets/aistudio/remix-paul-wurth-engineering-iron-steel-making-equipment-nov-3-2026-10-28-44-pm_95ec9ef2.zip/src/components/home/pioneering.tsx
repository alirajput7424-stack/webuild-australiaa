import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';

export function Pioneering() {
  return (
    <section id="pioneering" className="pioneering section-rail">
      <p className="eyebrow">
        <span></span>01 / A PIONEERING SPIRIT
      </p>
      <div>
        <h2>
          Built on experience.
          <br />
          Driven by <em>what’s next.</em>
        </h2>
        <p className="body-copy">
          Rooted in Luxembourg since 7 August 1997, Paul Wurth combines engineering heritage with a forward-looking purpose. We design, build and modernize the equipment that turns raw materials into liquid iron — efficiently, reliably and with a clear eye on decarbonization.
        </p>
        <Link to="/company" className="text-link">
          Our story, our ambition <ArrowUpRight size={18} />
        </Link>
        <div className="facts">
          <div>
            <strong>1997</strong>
            <span>Founded 7 August 1997</span>
          </div>
          <div>
            <strong>~500</strong>
            <span>employees in Luxembourg</span>
          </div>
          <div>
            <strong>Global</strong>
            <span>expertise. Luxembourg roots.</span>
          </div>
        </div>
      </div>
    </section>
  );
}
