import { Link } from 'react-router-dom';
import { ArrowUpRight, MapPin, Phone } from 'lucide-react';
import {
  companyAddress,
  companyMapsUrl,
  companyPhone,
  companyPhoneRaw,
  departmentImages,
  jobOpenings,
} from '@/data/site';

const featuredDepartments = [
  'Blast Furnace Engineering',
  'Process & Technology',
  'Electrical & Control Systems',
  'Digital & Innovation',
];

export function Careers() {
  const featured = featuredDepartments
    .map((team) => jobOpenings.find((job) => job.team === team))
    .filter((job): job is NonNullable<typeof job> => Boolean(job));

  return (
    <section id="careers" className="careers section-rail">
      <div className="careers-intro">
        <p className="eyebrow">
          <span></span>03 / BUILD YOUR FUTURE
        </p>
        <h2>
          Work that
          <br />
          <em>builds tomorrow.</em>
        </h2>
        <p>
          Join a Luxembourg-rooted engineering group where metallurgical heritage meets a forward-looking purpose. We are hiring across blast furnace engineering, process technology, electrical & automation and digital plant innovation.
        </p>
        <Link to="/careers" className="text-link">
          View all openings <ArrowUpRight size={18} />
        </Link>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginTop: '28px' }}>
          <a
            href={companyMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="careers-address"
            title="Open Paul Wurth location on Google Maps"
            style={{ margin: 0 }}
          >
            <MapPin size={15} />
            <span>{companyAddress} ↗</span>
          </a>
          <a
            href={`tel:${companyPhoneRaw}`}
            className="careers-address"
            title="Call Paul Wurth Luxembourg"
            style={{ margin: 0 }}
          >
            <Phone size={15} />
            <span>{companyPhone}</span>
          </a>
        </div>
      </div>
      <div className="careers-depts">
        {featured.map((job) => (
          <Link key={job.role} to="/careers" className="dept-card group">
            <div className="dept-image">
              <img
                src={departmentImages[job.team as keyof typeof departmentImages]}
                alt={`${job.team} team at work`}
                loading="lazy"
              />
              <span className="dept-tag">{job.team}</span>
            </div>
            <div className="dept-body">
              <h3>{job.role}</h3>
              <span className="dept-arrow" aria-hidden="true">
                <ArrowUpRight size={18} />
              </span>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
