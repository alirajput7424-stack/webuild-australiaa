import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';

export function Future() {
  return (
    <section className="future section-rail">
      <div>
        <p className="eyebrow">
          <span></span>02 / ENGINEERING THE TRANSITION
        </p>
        <h2>
          Less carbon.
          <br />
          More possibility.
        </h2>
        <p>
          Progress and environmental responsibility must move together. We are helping shape the next chapter of iron and steel-making.
        </p>
        <Link className="text-link" to="/technologies">
          Explore our expertise <ArrowUpRight size={19} />
        </Link>
        <div className="hydrogen-graphic" aria-hidden="true">
          <span>↓CO₂</span>
          <small>LOWER-CARBON IRON</small>
        </div>
      </div>
      <div className="expertise-list">
        {[
          [
            '01',
            'Blast furnace engineering',
            'Furnaces, hot blast stoves and charging systems built for long campaign life.',
            'technologies',
          ],
          [
            '02',
            'Decarbonization pathways',
            'Hydrogen, gas recovery and efficiency for lower-carbon iron-making.',
            'technologies',
          ],
          [
            '03',
            'Innovation & digitalisation',
            'Connecting metallurgical know-how with the power of plant data.',
            'innovation',
          ],
          [
            '04',
            'People & responsibility',
            'Creating lasting value for communities and future generations.',
            'responsibility',
          ],
        ].map(([n, title, text, url]) => (
          <Link key={n} to={'/' + url}>
            <span className="eyebrow">{n}</span>
            <div>
              <h3>{title}</h3>
              <p>{text}</p>
            </div>
            <ArrowUpRight size={23} />
          </Link>
        ))}
      </div>
    </section>
  );
}
