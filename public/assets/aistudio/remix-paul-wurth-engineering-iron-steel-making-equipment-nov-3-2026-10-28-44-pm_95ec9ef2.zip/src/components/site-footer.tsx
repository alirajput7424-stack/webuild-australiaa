import { Link } from 'react-router-dom';
import { MapPin, Mail, Phone } from 'lucide-react';
import { openCookiePreferences } from '@/lib/cookie-consent';
import { logoImage, companyAddress, companyMapsUrl, officialEmail, companyPhone, companyPhoneRaw } from '@/data/site';
import { officialGmailUrl } from '@/lib/contact-links';
import { PWLogo } from '@/components/pw-logo';

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div>
        <span className="footer-brand" style={{ display: 'inline-flex', alignItems: 'center', gap: '8px' }}>
          <PWLogo size="sm" /> Paul Wurth
        </span>
        <p>
          Building a better tomorrow.
          <br />
          Luxembourg · Part of SMS group
        </p>
        <a
          className="footer-address"
          href={companyMapsUrl}
          target="_blank"
          rel="noopener noreferrer"
          title="Open Paul Wurth location on Google Maps"
        >
          <MapPin size={13} /> {companyAddress} ↗
        </a>
        <a
          className="footer-address"
          href={`tel:${companyPhoneRaw}`}
          title="Call Paul Wurth Luxembourg"
          style={{ marginTop: '8px' }}
        >
          <Phone size={13} /> {companyPhone}
        </a>
        <a
          className="footer-address"
          href={officialGmailUrl}
          target="_blank"
          rel="noopener noreferrer"
          title={`Open Gmail and contact us at ${officialEmail}`}
          style={{ marginTop: '8px' }}
        >
          <Mail size={13} /> {officialEmail} (Gmail) ↗
        </a>
      </div>
      <div>
        <Link to="/company">Our company</Link>
        <Link to="/responsibility">People & responsibility</Link>
        <Link to="/careers">Careers</Link>
        <Link to="/verify">Job-letter verification</Link>
      </div>
      <div>
        <a href="https://www.sms-group.com" target="_blank" rel="noreferrer">
          SMS group ↗
        </a>
        <Link to="/verify#privacy">Document privacy</Link>
        <Link to="/qr">Verification QR</Link>
        <Link to="/login">Staff sign in</Link>
        <button type="button" onClick={openCookiePreferences}>
          Cookie settings
        </button>
      </div>
      <div className="footer-bottom">
        © 2026 Paul Wurth S.A.
        <span>Rooted in Luxembourg. Building worldwide.</span>
      </div>
    </footer>
  );
}
