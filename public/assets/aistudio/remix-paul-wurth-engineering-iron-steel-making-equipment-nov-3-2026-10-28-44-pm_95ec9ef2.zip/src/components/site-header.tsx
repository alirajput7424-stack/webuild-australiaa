import { Link, NavLink } from 'react-router-dom';
import { Menu, X, Phone } from 'lucide-react';
import { useDisclosure } from '@/hooks/use-disclosure';
import { logoImage, officialEmail, companyPhone, companyPhoneRaw } from '@/data/site';
import { officialGmailUrl } from '@/lib/contact-links';
import { MessageLogo } from '@/components/message-logo';
import { PWLogo } from '@/components/pw-logo';

export function SiteHeader() {
  const menu = useDisclosure();

  return (
    <header className="site-header corporate-header">
      <div className="header-bar">
        <Link to="/" className="wordmark" aria-label="Paul Wurth home">
          <PWLogo size="md" />
          <span className="wordmark-name">
            <b className="wm-blue">Paul</b> <b className="wm-red">Wurth</b>
          </span>
        </Link>
        <nav className="desktop-nav" aria-label="Main navigation">
          <NavLink to="/company" className={({ isActive }) => (isActive ? 'active' : '')}>
            About us
          </NavLink>
          <NavLink to="/technologies" className={({ isActive }) => (isActive ? 'active' : '')}>
            Technology
          </NavLink>
          <NavLink to="/innovation" className={({ isActive }) => (isActive ? 'active' : '')}>
            Innovation
          </NavLink>
          <NavLink to="/responsibility" className={({ isActive }) => (isActive ? 'active' : '')}>
            Responsibility
          </NavLink>
          <NavLink to="/careers" className={({ isActive }) => (isActive ? 'active' : '')}>
            Career
          </NavLink>
        </nav>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <a
            className="header-email-btn"
            href={officialGmailUrl}
            target="_blank"
            rel="noopener noreferrer"
            title={`Open Gmail and contact us at ${officialEmail}`}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              padding: '6px 12px 6px 6px',
              border: '1px solid #c9d6ce',
              background: '#f6f8f6',
              color: '#1d352c',
              borderRadius: '20px',
              fontSize: '11px',
              fontWeight: 600,
              textDecoration: 'none',
              transition: 'all 0.2s ease',
            }}
          >
            <MessageLogo size="sm" withPulse />
            <span>Email us</span>
          </a>
          <Link className="header-action" to="/verify">
            Verify a job letter
          </Link>
        </div>
        <button className="menu-toggle" {...menu.triggerProps} aria-label="Toggle menu">
          {menu.isOpen ? <X /> : <Menu />}
        </button>
        {menu.isOpen && (
          <nav className="mobile-nav" {...menu.panelProps} aria-label="Mobile navigation">
            <Link to="/company" onClick={menu.close}>
              About us
            </Link>
            <Link to="/technologies" onClick={menu.close}>
              Technology
            </Link>
            <Link to="/innovation" onClick={menu.close}>
              Innovation
            </Link>
            <Link to="/responsibility" onClick={menu.close}>
              Responsibility
            </Link>
            <Link to="/careers" onClick={menu.close}>
              Career
            </Link>
            <Link to="/verify" onClick={menu.close}>
              Verify a job letter
            </Link>
            <a
              href={`tel:${companyPhoneRaw}`}
              onClick={menu.close}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '8px',
                padding: '10px 14px',
                background: '#f6f8f6',
                color: '#1d352c',
                border: '1px solid #c9d6ce',
                borderRadius: '6px',
                fontWeight: 600,
                fontSize: '12px',
                textDecoration: 'none',
                marginTop: '6px',
              }}
            >
              <Phone size={14} />
              <span>Call: {companyPhone}</span>
            </a>
            <a
              href={officialGmailUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={menu.close}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '8px',
                padding: '10px 14px',
                background: '#1d352c',
                color: '#ffffff',
                borderRadius: '6px',
                fontWeight: 600,
                fontSize: '12px',
                textDecoration: 'none',
                marginTop: '6px',
              }}
            >
              <MessageLogo size="sm" />
              <span>Email us on Gmail: {officialEmail} ↗</span>
            </a>
          </nav>
        )}
      </div>
    </header>
  );
}
