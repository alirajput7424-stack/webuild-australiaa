import { useState } from 'react';
import {
  ShieldCheck,
  Upload,
  ArrowUpRight,
  KeyRound,
  BadgeCheck,
  Building2,
  Lock,
  Printer,
  FileText,
  AlertCircle,
  Copy,
  Check,
  ArrowLeft,
  Briefcase,
} from 'lucide-react';
import { validateSecretKey } from '@/data/secret-keys';
import { pocketbaseClient, type VerificationItem } from '@/lib/pocketbase-client';

export function VerificationForm() {
  const [step, setStep] = useState<'submit' | 'enter_key' | 'verified'>('submit');

  // Step 1 Form fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [fileName, setFileName] = useState('');
  const [context, setContext] = useState('');
  const [consent, setConsent] = useState(true);
  const [fileObject, setFileObject] = useState<File | null>(null);

  // Saved record reference from Step 1
  const [currentRecord, setCurrentRecord] = useState<VerificationItem | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [validation, setValidation] = useState('');

  // Step 2 Secret Key fields
  const [secretKeyInput, setSecretKeyInput] = useState('');
  const [keyError, setKeyError] = useState('');
  const [verifyingKey, setVerifyingKey] = useState(false);
  const [copied, setCopied] = useState(false);

  // Step 1: Submit Details & PDF
  async function handleStep1Submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setValidation('');

    if (!name.trim()) {
      setValidation('Please enter your exact registered full name.');
      return;
    }
    if (!email.trim()) {
      setValidation('Please enter your registered email address.');
      return;
    }
    if (!fileObject) {
      setValidation('Please upload your job offer letter (PDF).');
      return;
    }

    if (!fileObject.name.toLowerCase().endsWith('.pdf') || fileObject.size > 10 * 1024 * 1024) {
      setValidation('Please upload a valid PDF document (maximum 10 MB).');
      return;
    }

    setSubmitting(true);

    try {
      const formData = new FormData();
      formData.set('name', name.trim());
      formData.set('email', email.trim());
      formData.set('document', fileObject);
      formData.set('context', context.trim());
      formData.set('consent', consent ? 'true' : 'false');

      const record = (await pocketbaseClient
        .collection('verification_requests')
        .create(formData)) as unknown as VerificationItem;

      setCurrentRecord(record);
      setSubmitting(false);
      // Move to Step 2 (Enter Secret Key)
      setStep('enter_key');
      window.scrollTo({ top: 100, behavior: 'smooth' });
    } catch {
      setValidation('Submission error. Please verify your details and try again.');
      setSubmitting(false);
    }
  }

  // Step 2: Validate 10-Digit Secret Key
  function handleKeySubmit(e: React.FormEvent) {
    e.preventDefault();
    setKeyError('');

    const cleanInput = secretKeyInput.trim().replace(/\D/g, '');

    if (cleanInput.length !== 10) {
      setKeyError('The secret verification key must be exactly 10 digits.');
      return;
    }

    setVerifyingKey(true);

    setTimeout(() => {
      const result = validateSecretKey(cleanInput, currentRecord?.secretKey);

      if (result.isValid) {
        setStep('verified');
        window.scrollTo({ top: 100, behavior: 'smooth' });
      } else {
        setKeyError(
          'Invalid 10-digit Key: The code entered was not found in our authorization records. Please contact your default recruitment agency to obtain your official 10-digit key.'
        );
      }
      setVerifyingKey(false);
    }, 700);
  }

  function printCertificate() {
    window.print();
  }

  function copyText(val: string) {
    navigator.clipboard.writeText(val);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  function restartFlow() {
    setStep('submit');
    setName('');
    setEmail('');
    setFileName('');
    setFileObject(null);
    setContext('');
    setSecretKeyInput('');
    setValidation('');
    setKeyError('');
    setCurrentRecord(null);
  }

  return (
    <main className="verification">
      {/* Left Column: Official Explanations */}
      <div className="verification-copy">
        <p className="eyebrow">
          <span></span>RECRUITMENT / DOCUMENT VERIFICATION
        </p>
        <h1>
          Offer letter
          <br />
          <em>verification portal.</em>
        </h1>
        <p>
          Paul Wurth Geprolux S.A. uses an authorized 10-digit security key verification system to authenticate official employment offers and protect candidates from counterfeit documentation.
        </p>

        {/* Step Indicator Card */}
        <div
          style={{
            marginTop: '24px',
            padding: '20px',
            background: '#ffffff',
            border: '1px solid var(--line)',
            borderRadius: '8px',
          }}
        >
          <strong style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '1px', color: '#1d352c' }}>
            Two-Step Verification Process:
          </strong>

          <div style={{ marginTop: '14px', display: 'flex', flexDirection: 'column', gap: '12px', fontSize: '13px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span
                style={{
                  width: '24px',
                  height: '24px',
                  borderRadius: '50%',
                  background: step === 'submit' ? '#1d352c' : '#10b981',
                  color: '#ffffff',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '11px',
                  fontWeight: 700,
                  flexShrink: 0,
                }}
              >
                {step === 'submit' ? '1' : '✓'}
              </span>
              <span style={{ fontWeight: step === 'submit' ? 700 : 500, color: step === 'submit' ? '#1d352c' : '#68746c' }}>
                Step 1: Enter exact registered name, email & upload PDF offer letter
              </span>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span
                style={{
                  width: '24px',
                  height: '24px',
                  borderRadius: '50%',
                  background: step === 'enter_key' ? '#1d352c' : step === 'verified' ? '#10b981' : '#e5e7eb',
                  color: step === 'submit' ? '#68746c' : '#ffffff',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '11px',
                  fontWeight: 700,
                  flexShrink: 0,
                }}
              >
                {step === 'verified' ? '✓' : '2'}
              </span>
              <span style={{ fontWeight: step === 'enter_key' ? 700 : 500, color: step === 'enter_key' ? '#1d352c' : '#68746c' }}>
                Step 2: Enter 10-digit Secret Key provided by your agency
              </span>
            </div>
          </div>
        </div>

        <div className="security-note" style={{ marginTop: '24px' }}>
          <Lock size={32} style={{ color: '#1d352c', flexShrink: 0 }} />
          <div>
            <h2>Authorized Agency Key System</h2>
            <p>
              To ensure data protection and prevent unauthorized tampering, official 10-digit security keys are provided exclusively to authorized consultants and default recruitment agencies.
            </p>
          </div>
        </div>
      </div>

      {/* Right Column: Interactive Step Panels */}
      <div className="verification-panel">
        {/* ================= STEP 1: SUBMIT DETAILS & PDF ================= */}
        {step === 'submit' && (
          <form onSubmit={handleStep1Submit}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
              <span style={{ fontFamily: 'monospace', fontSize: '11px', background: '#e8f0ea', color: '#1d352c', padding: '2px 8px', borderRadius: '4px', fontWeight: 700 }}>
                STEP 1 OF 2
              </span>
            </div>
            <h2>Candidate & Document Details</h2>
            <p>Please enter your exact registered name and email, and attach your PDF offer letter to begin verification.</p>

            <label style={{ marginTop: '16px' }}>
              Exact Registered Full Name *
              <input
                name="name"
                required
                maxLength={150}
                autoComplete="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your registered full name"
              />
            </label>

            <label>
              Registered Email Address *
              <input
                name="email"
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your registered email address"
              />
            </label>

            <label className="upload-zone" style={{ cursor: 'pointer', marginTop: '14px' }}>
              <Upload size={28} style={{ color: '#1d352c' }} />
              <strong>{fileName || 'Upload Job Offer Letter (PDF) *'}</strong>
              <span>PDF documents only · Maximum 10 MB</span>
              <input
                name="document"
                type="file"
                accept="application/pdf,.pdf"
                required
                onChange={(e) => {
                  const file = e.target.files?.[0] || null;
                  setFileObject(file);
                  setFileName(file?.name || '');
                }}
              />
            </label>

            <label>
              Additional Information (optional)
              <textarea
                name="context"
                rows={2}
                maxLength={3000}
                value={context}
                onChange={(e) => setContext(e.target.value)}
                placeholder="Default recruitment agency name, consultant name, or position applied for"
              />
            </label>

            <label className="consent-line">
              <input
                type="checkbox"
                name="consent"
                checked={consent}
                onChange={(e) => setConsent(e.target.checked)}
                required
              />
              I agree to verify this document against official Paul Wurth Geprolux recruitment records. *
            </label>

            {validation && (
              <p className="form-error" role="alert" style={{ color: '#a12c2c', margin: '14px 0' }}>
                {validation}
              </p>
            )}

            <button
              className="solid-button"
              type="submit"
              disabled={submitting}
              style={{ marginTop: '16px' }}
            >
              <span>{submitting ? 'Registering Document…' : 'Submit for Verification'}</span>
              <ArrowUpRight size={18} />
            </button>
          </form>
        )}

        {/* ================= STEP 2: ENTER 10-DIGIT SECRET KEY ================= */}
        {step === 'enter_key' && (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
              <span style={{ fontFamily: 'monospace', fontSize: '11px', background: '#fef3c7', color: '#92400e', padding: '2px 8px', borderRadius: '4px', fontWeight: 700 }}>
                STEP 2 OF 2 · AUTHORIZATION REQUIRED
              </span>
            </div>

            <h2>Enter 10-Digit Secret Verification Key</h2>

            {/* MANDATORY NOTICE (Requested by user) */}
            <div
              style={{
                marginTop: '16px',
                padding: '18px',
                background: '#eff6ff',
                border: '2px solid #3b82f6',
                borderRadius: '8px',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#1e40af', fontWeight: 800, fontSize: '13.5px' }}>
                <KeyRound size={20} />
                <span>AGENCY SECURITY KEY DISPATCH NOTICE</span>
              </div>
              <p style={{ fontSize: '13px', color: '#1e3a8a', marginTop: '8px', lineHeight: '1.7', fontWeight: 600 }}>
                A Unique 10-digit Security ID has been sent to your Default Agency from where you applied for the job.
              </p>
              <p style={{ fontSize: '12px', color: '#3b82f6', marginTop: '6px', lineHeight: '1.6' }}>
                Please contact your authorized agency / consultant to receive your official 10-digit secret verification key and enter it below to unlock the verified status of your offer letter.
              </p>
            </div>

            {/* Applicant Summary */}
            <div
              style={{
                marginTop: '16px',
                padding: '12px 16px',
                background: '#f8faf9',
                border: '1px solid var(--line)',
                borderRadius: '6px',
                fontSize: '12px',
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
                gap: '8px',
              }}
            >
              <div>
                <span style={{ color: '#68746c', fontSize: '10.5px' }}>Registered Candidate:</span>
                <div style={{ fontWeight: 700, color: '#1d352c' }}>{name}</div>
              </div>
              <div>
                <span style={{ color: '#68746c', fontSize: '10.5px' }}>Contact Email:</span>
                <div style={{ fontWeight: 600, color: '#1d352c' }}>{email}</div>
              </div>
              <div>
                <span style={{ color: '#68746c', fontSize: '10.5px' }}>Attached File:</span>
                <div style={{ fontWeight: 600, color: '#1d352c', wordBreak: 'break-all' }}>{fileName}</div>
              </div>
            </div>

            <form onSubmit={handleKeySubmit} style={{ marginTop: '20px' }}>
              <label>
                Enter 10-Digit Secret Verification Key *
                <input
                  type="text"
                  required
                  maxLength={10}
                  value={secretKeyInput}
                  onChange={(e) => setSecretKeyInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="••••••••••"
                  style={{
                    fontSize: '20px',
                    fontFamily: 'monospace',
                    letterSpacing: '4px',
                    fontWeight: 700,
                    textAlign: 'center',
                    padding: '14px',
                    border: '2px solid #1d352c',
                    background: '#ffffff',
                    color: '#1d352c',
                  }}
                />
              </label>

              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#68746c', marginTop: '4px' }}>
                <span>Digits entered: {secretKeyInput.length} / 10</span>
                <span>Numbers only</span>
              </div>

              {keyError && (
                <div
                  style={{
                    marginTop: '14px',
                    padding: '12px 14px',
                    background: '#fef2f2',
                    border: '1.5px solid #ef4444',
                    borderRadius: '6px',
                    color: '#991b1b',
                    fontSize: '12.5px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                  }}
                >
                  <AlertCircle size={18} style={{ flexShrink: 0 }} />
                  <span>{keyError}</span>
                </div>
              )}

              <button
                className="solid-button"
                type="submit"
                disabled={verifyingKey || secretKeyInput.length !== 10}
                style={{ marginTop: '18px' }}
              >
                <span>{verifyingKey ? 'Authenticating Key…' : 'Verify Secret Key & View Status'}</span>
                <ArrowUpRight size={18} />
              </button>

              <button
                type="button"
                onClick={() => setStep('submit')}
                style={{
                  marginTop: '12px',
                  background: 'none',
                  border: 'none',
                  color: '#68746c',
                  fontSize: '12px',
                  cursor: 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '4px',
                  textDecoration: 'underline',
                }}
              >
                <ArrowLeft size={13} /> Edit candidate or document details
              </button>
            </form>
          </div>
        )}

        {/* ================= STEP 3: UNLOCKED & VERIFIED STATUS ================= */}
        {step === 'verified' && (
          <div
            id="verification-certificate"
            style={{
              padding: '28px',
              background: '#ffffff',
              border: '2.5px solid #10b981',
              borderRadius: '10px',
              boxShadow: '0 12px 36px rgba(16, 185, 129, 0.16)',
            }}
          >
            {/* Status Header Badge */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                gap: '12px',
                paddingBottom: '16px',
                borderBottom: '1px solid var(--line)',
              }}
            >
              <div
                style={{
                  background: '#d1fae5',
                  color: '#065f46',
                  padding: '8px 18px',
                  borderRadius: '30px',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '8px',
                  fontSize: '14px',
                  fontWeight: 800,
                  letterSpacing: '0.5px',
                  fontFamily: 'Manrope, sans-serif',
                  border: '1.5px solid #10b981',
                }}
              >
                <BadgeCheck size={22} style={{ color: '#059669' }} />
                REAL & OFFICIALLY VERIFIED
              </div>

              <div
                style={{
                  fontFamily: 'monospace',
                  fontSize: '12px',
                  color: '#1d352c',
                  background: '#f6f6f1',
                  padding: '6px 14px',
                  borderRadius: '4px',
                  border: '1px solid var(--line)',
                }}
              >
                Secret Key: <strong>{secretKeyInput}</strong> (AUTHENTICATED)
              </div>
            </div>

            {/* Candidate & Document Verified Details */}
            <div style={{ marginTop: '18px' }}>
              <span
                style={{
                  fontSize: '10px',
                  fontFamily: 'monospace',
                  letterSpacing: '1.5px',
                  textTransform: 'uppercase',
                  color: '#1d352c',
                  fontWeight: 700,
                }}
              >
                PAUL WURTH GEPROLUX S.A. · VERIFIED OFFER LETTER
              </span>

              <h3
                style={{
                  fontSize: '26px',
                  fontFamily: "'Libre Caslon Display', Georgia, serif",
                  color: '#1d352c',
                  marginTop: '4px',
                }}
              >
                {name}
              </h3>
              <p style={{ fontSize: '13px', color: '#68746c', marginTop: '2px' }}>
                {email} · Document: <strong>{fileName}</strong>
              </p>

              {/* Official HR Statement Banner */}
              <div
                style={{
                  marginTop: '16px',
                  padding: '16px',
                  background: '#f0fdf4',
                  border: '1px solid #bbf7d0',
                  borderRadius: '6px',
                  fontSize: '13px',
                  lineHeight: '1.7',
                  color: '#1f2937',
                }}
              >
                <strong style={{ color: '#065f46' }}>Official HR Directorate Authentication:</strong>
                <p style={{ marginTop: '6px', fontSize: '12.5px', color: '#374151' }}>
                  The 10-digit secret verification key <code>{secretKeyInput}</code> provided by your default recruitment agency has been confirmed against our official Luxembourg registry. Paul Wurth Geprolux S.A. certifies that this offer letter for <strong>{name}</strong> is <strong>AUTHENTIC, APPROVED, and OFFICIALLY RECORDED</strong>.
                </p>
              </div>

              {/* Details Grid */}
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                  gap: '14px',
                  marginTop: '18px',
                  padding: '16px',
                  background: '#f9fafb',
                  border: '1px solid var(--line)',
                  borderRadius: '6px',
                  fontSize: '12px',
                }}
              >
                <div>
                  <span style={{ color: '#68746c', fontSize: '10px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                    Document Status:
                  </span>
                  <div style={{ fontWeight: 700, color: '#059669', marginTop: '2px' }}>
                    Approved & Verified Genuine
                  </div>
                </div>

                <div>
                  <span style={{ color: '#68746c', fontSize: '10px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                    Issuing Authority:
                  </span>
                  <div style={{ fontWeight: 600, color: '#1d352c', marginTop: '2px' }}>
                    <Building2 size={13} style={{ display: 'inline', marginRight: '4px' }} />
                    Paul Wurth Geprolux S.A. (Luxembourg)
                  </div>
                </div>

                <div>
                  <span style={{ color: '#68746c', fontSize: '10px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                    Tracking Ref:
                  </span>
                  <div style={{ fontWeight: 600, color: '#1d352c', marginTop: '2px', fontFamily: 'monospace' }}>
                    {currentRecord?.refCode || `PW-LUX-${Math.floor(100000 + Math.random() * 900000)}`}
                  </div>
                </div>

                <div>
                  <span style={{ color: '#68746c', fontSize: '10px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                    Verification Date:
                  </span>
                  <div style={{ fontWeight: 600, color: '#1d352c', marginTop: '2px' }}>
                    {new Date().toLocaleDateString('en-GB')}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div style={{ display: 'flex', gap: '10px', marginTop: '22px', flexWrap: 'wrap' }}>
                <button
                  type="button"
                  onClick={printCertificate}
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '6px',
                    padding: '10px 18px',
                    background: '#1d352c',
                    color: '#ffffff',
                    border: 'none',
                    borderRadius: '4px',
                    fontSize: '12px',
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  <Printer size={15} /> Print / Save Certificate
                </button>

                <button
                  type="button"
                  onClick={() => copyText(secretKeyInput)}
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '6px',
                    padding: '10px 16px',
                    background: '#f6f6f1',
                    color: '#1d352c',
                    border: '1px solid var(--line)',
                    borderRadius: '4px',
                    fontSize: '12px',
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  {copied ? <Check size={15} style={{ color: '#10b981' }} /> : <Copy size={15} />}
                  {copied ? 'Copied Key!' : 'Copy Key'}
                </button>

                <button
                  type="button"
                  onClick={restartFlow}
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '6px',
                    padding: '10px 16px',
                    background: 'transparent',
                    color: '#68746c',
                    border: 'none',
                    fontSize: '12px',
                    cursor: 'pointer',
                    marginLeft: 'auto',
                    textDecoration: 'underline',
                  }}
                >
                  Verify Another Letter
                </button>
              </div>
            </div>
          </div>
        )}

        <div id="privacy" className="privacy-note">
          <strong>Official Security & Privacy Guarantee</strong>
          <p>
            Document submissions and 10-digit secret keys are handled in strict compliance with European GDPR and Luxembourg recruitment security standards.
          </p>
        </div>
      </div>
    </main>
  );
}
