import { Link } from 'react-router-dom';
import { ArrowUpRight, MapPin, Mail, Briefcase, Phone } from 'lucide-react';
import { careersImage, companyAddress, companyMapsUrl, officialEmail, companyPhone, companyPhoneRaw, jobOpenings } from '@/data/site';
import { officialGmailUrl } from '@/lib/contact-links';

export function CareersContent() {
  return (
    <main className="careers-page">
      <section className="careers-hero">
        <p className="eyebrow">
          <span></span>CAREERS / BUILD YOUR FUTURE
        </p>
        <h1>
          Build your future
          <br />
          <em>in iron & steel.</em>
        </h1>
        <p>
          Paul Wurth brings together international iron & steel-making challenges and a strong Luxembourg engineering base. We are looking for mechanical and process engineers, project managers, automation specialists and digital plant experts who want to shape the future of metal production.
        </p>
        <div className="careers-hero-meta">
          <span>
            <Briefcase size={15} /> {jobOpenings.length} open roles
          </span>
          <a
            href={companyMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            title="Open Paul Wurth location on Google Maps"
            style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', color: 'inherit', textDecoration: 'none' }}
          >
            <MapPin size={15} /> {companyAddress} ↗
          </a>
        </div>
      </section>
      <section className="careers-banner">
        <img
          src={careersImage}
          alt="Engineers reviewing technical drawings in a steel plant control room"
          loading="lazy"
        />
      </section>
      <section className="careers-openings">
        <p className="eyebrow">
          <span></span>OPEN POSITIONS
        </p>
        <h2>Current opportunities</h2>
        <p className="body-copy">
          All roles are based at our Hollerich office and across customer plant sites worldwide. Don't see a perfect fit? Send us your CV — we are always interested in talented people.
        </p>
        <div className="openings-list">
          {jobOpenings.map((job) => (
            <article key={job.role} className="opening">
              <div className="opening-head">
                <h3>{job.role}</h3>
                <span className="opening-team">{job.team}</span>
              </div>
              <p>{job.summary}</p>
              <small>
                {job.location} · {job.type}
              </small>
              <a
                className="text-link"
                href="https://www.sms-group.com/careers"
                target="_blank"
                rel="noreferrer"
              >
                Apply <ArrowUpRight size={17} />
              </a>
            </article>
          ))}
        </div>
      </section>
      <section className="careers-apply">
        <div>
          <p className="eyebrow">
            <span></span>HOW TO APPLY
          </p>
          <h2>Ready to build with us?</h2>
          <p className="body-copy">
            Apply through the official SMS group careers channels, or send your CV and cover letter to our recruitment team. We review every application and respond to suitable candidates.
          </p>
          <ul className="apply-steps">
            <li>
              <span>01</span> Prepare your CV and a short cover letter.
            </li>
            <li>
              <span>02</span> Apply via the SMS group careers portal or by email.
            </li>
            <li>
              <span>03</span> Our recruitment team reviews and responds to suitable candidates.
            </li>
          </ul>
        </div>
        <div className="apply-panel">
          <div className="apply-contact">
            <a
              href={officialGmailUrl}
              target="_blank"
              rel="noopener noreferrer"
              style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', color: 'inherit', textDecoration: 'none' }}
              title={`Open Gmail and contact us at ${officialEmail}`}
            >
              <Mail size={16} /> {officialEmail} (Gmail) ↗
            </a>
            <a
              href={`tel:${companyPhoneRaw}`}
              style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', color: 'inherit', textDecoration: 'none' }}
              title="Call Paul Wurth Luxembourg"
            >
              <Phone size={16} /> {companyPhone}
            </a>
            <a
              href={companyMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              title="Open Paul Wurth location on Google Maps"
              style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', color: 'inherit', textDecoration: 'none' }}
            >
              <MapPin size={16} /> {companyAddress} ↗
            </a>
          </div>
          <a
            className="solid-button"
            href="https://www.sms-group.com/careers"
            target="_blank"
            rel="noreferrer"
          >
            Apply on SMS group careers <ArrowUpRight size={18} />
          </a>
          <p className="apply-note" style={{ marginTop: '16px', fontSize: '11px', color: 'var(--mint)' }}>
            Received a job letter and unsure it is genuine?{' '}
            <Link to="/verify" style={{ textDecoration: 'underline', color: '#fff' }}>
              Request a verification
            </Link>
            .
          </p>
        </div>
      </section>
    </main>
  );
}
