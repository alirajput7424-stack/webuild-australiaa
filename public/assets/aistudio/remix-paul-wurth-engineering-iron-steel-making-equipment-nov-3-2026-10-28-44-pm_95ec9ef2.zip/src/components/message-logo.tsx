interface MessageLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  withPulse?: boolean;
}

export function MessageLogo({ size = 'md', className = '', withPulse = false }: MessageLogoProps) {
  const dimensions = {
    sm: { box: 32, icon: 16, pulse: 8 },
    md: { box: 44, icon: 22, pulse: 10 },
    lg: { box: 56, icon: 28, pulse: 12 },
    xl: { box: 68, icon: 34, pulse: 14 },
  }[size];

  return (
    <div
      className={`relative inline-flex items-center justify-center select-none ${className}`}
      style={{
        width: dimensions.box,
        height: dimensions.box,
      }}
    >
      {/* Outer Glow & Background */}
      <svg
        width={dimensions.box}
        height={dimensions.box}
        viewBox="0 0 48 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="transition-transform duration-300 group-hover:scale-105"
      >
        <defs>
          <linearGradient id="pw-msg-bg" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1d352c" />
            <stop offset="50%" stopColor="#25463a" />
            <stop offset="100%" stopColor="#0f1f19" />
          </linearGradient>
          <linearGradient id="pw-msg-border" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#bed3c3" stopOpacity="0.8" />
            <stop offset="50%" stopColor="#506257" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#bed3c3" stopOpacity="0.2" />
          </linearGradient>
          <linearGradient id="pw-envelope-grad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="100%" stopColor="#dbe8df" />
          </linearGradient>
          <linearGradient id="pw-accent-send" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00a3ff" />
            <stop offset="100%" stopColor="#0072b2" />
          </linearGradient>
          <filter id="pw-shadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="2" stdDeviation="2" floodColor="#000000" floodOpacity="0.3" />
          </filter>
        </defs>

        {/* Squircle Background */}
        <rect
          x="2"
          y="2"
          width="44"
          height="44"
          rx="12"
          fill="url(#pw-msg-bg)"
          stroke="url(#pw-msg-border)"
          strokeWidth="1.5"
          filter="url(#pw-shadow)"
        />

        {/* Envelope Base Body */}
        <path
          d="M10 16C10 14.8954 10.8954 14 12 14H36C37.1046 14 38 14.8954 38 16V32C38 33.1046 37.1046 34 36 34H12C10.8954 34 10 33.1046 10 32V16Z"
          fill="url(#pw-envelope-grad)"
          opacity="0.95"
        />

        {/* Interior Fold Shadows */}
        <path
          d="M10 32L21 23M38 32L27 23"
          stroke="#8ba294"
          strokeWidth="1.5"
          strokeLinecap="round"
        />

        {/* Envelope Flap (Top Crease) */}
        <path
          d="M10 16L22.2929 25.2197C23.2778 25.9584 24.7222 25.9584 25.7071 25.2197L38 16"
          stroke="#1d352c"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Golden / Mint Stamp Emblem in Corner */}
        <circle cx="34" cy="14" r="3.5" fill="#bed3c3" stroke="#1d352c" strokeWidth="1" />
        <path d="M34 12.5V15.5M32.5 14H35.5" stroke="#1d352c" strokeWidth="0.8" strokeLinecap="round" />

        {/* Modern Dynamic Fast-Send Notch */}
        <path
          d="M21 21.5L24 19L27 21.5"
          stroke="#1d352c"
          strokeWidth="1.2"
          strokeLinecap="round"
          strokeLinejoin="round"
          opacity="0.7"
        />
      </svg>

      {/* Real-time Online Beacon Pulse */}
      {withPulse && (
        <span
          className="absolute -top-1 -right-1 flex h-3.5 w-3.5"
          title="Direct messaging channel active"
        >
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500 border-2 border-white"></span>
        </span>
      )}
    </div>
  );
}
