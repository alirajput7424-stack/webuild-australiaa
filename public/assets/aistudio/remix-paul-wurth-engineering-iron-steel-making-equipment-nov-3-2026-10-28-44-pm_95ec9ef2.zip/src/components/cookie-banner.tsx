import { useCookieBanner } from '@/hooks/use-cookie-banner';

export function CookieBanner() {
  const b = useCookieBanner();
  if (!b.isOpen) return null;

  return (
    <section className="cookie-banner" role="dialog" aria-label="Cookie preferences">
      <div>
        <strong>Your privacy matters.</strong>
        <p>
          We use essential cookies to operate this site. Optional cookies help measure visits and improve services.
        </p>
      </div>
      {b.isCustomizing && (
        <fieldset>
          {(['analytics', 'marketing', 'platformAnalytics'] as const).map((key, i) => (
            <label key={key}>
              <input
                type="checkbox"
                checked={b.choices[key]}
                onChange={(e) => b.setChoice(key, e.target.checked)}
              />
              {
                [
                  'Analytics — visitor statistics',
                  'Marketing — ad measurement and personalised ads',
                  'Platform analytics — Hostinger service improvement',
                ][i]
              }
            </label>
          ))}
        </fieldset>
      )}
      <div className="cookie-actions">
        <button type="button" onClick={b.rejectOptional}>
          Reject optional
        </button>
        <button type="button" onClick={b.isCustomizing ? b.saveChoices : b.customize}>
          {b.isCustomizing ? 'Save choices' : 'Customize'}
        </button>
        <button type="button" onClick={b.acceptAll}>
          Accept all
        </button>
      </div>
    </section>
  );
}
