import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';
import { pages, industrialImage, type PageKey } from '@/data/site';

export function EditorialContent({ pageKey }: { pageKey: PageKey }) {
  const p = pages[pageKey];
  if (!p) return null;

  return (
    <main className="editorial">
      <div className="editorial-title">
        <p className="eyebrow">
          <span></span>{p.eyebrow}
        </p>
        <h1>{p.title}</h1>
        <p>{p.intro}</p>
      </div>
      <img
        className="editorial-image"
        src={industrialImage}
        alt="Industrial iron-making plant with blast furnace and hot blast stoves"
        width="1472"
        height="640"
      />
      <div className="editorial-sections">
        {p.sections.map((s, i) => (
          <section key={s.title}>
            <span className="eyebrow">0{i + 1}</span>
            <h2>{s.title}</h2>
            <p>{s.text}</p>
          </section>
        ))}
      </div>
      <div className="editorial-cta">
        <h2>Confidence begins with clarity.</h2>
        <Link to="/verify" className="text-link">
          Verify a job letter <ArrowUpRight size={20} />
        </Link>
      </div>
    </main>
  );
}
