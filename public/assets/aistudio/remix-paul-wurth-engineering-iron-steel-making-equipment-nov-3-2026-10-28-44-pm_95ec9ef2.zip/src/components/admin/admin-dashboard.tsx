import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LogOut, QrCode } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { usePocketbaseRecords } from '@/hooks/use-pocketbase-records';
import { RequestDetail } from '@/components/admin/request-detail';
import type { VerificationRequest } from '@/components/admin/types';

type Props = {
  user: { email?: string } | null;
};

export function AdminDashboard({ user: _user }: Props) {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const records = usePocketbaseRecords<VerificationRequest>('verification_requests', {
    sort: '-created',
    realtime: true,
  });

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const selected = records.records.find((r) => r.id === selectedId) ?? null;

  async function handleLogout() {
    logout();
    navigate('/login');
  }

  return (
    <main className="admin-page">
      <div className="admin-head">
        <div>
          <p className="eyebrow">
            <span></span>ADMIN / VERIFICATION REQUESTS
          </p>
          <h1>Verification requests</h1>
          <p className="body-copy">
            Review submitted job letters, open the PDF and respond to applicants by email. Responses are sent from the site’s official email identity.
          </p>
        </div>
        <div className="admin-actions">
          <Link to="/qr">
            <QrCode size={14} /> QR code
          </Link>
          <button type="button" onClick={handleLogout}>
            <LogOut size={14} /> Sign out
          </button>
        </div>
      </div>

      <div className="admin-layout">
        <div className="admin-list">
          <div className="admin-list-head">
            <span>Applicant</span>
            <span>{records.totalItems} total</span>
          </div>
          {records.isLoading ? (
            <div className="admin-loading">Loading…</div>
          ) : records.records.length === 0 ? (
            <div className="admin-empty">No verification requests yet.</div>
          ) : (
            records.records.map((r) => (
              <button
                type="button"
                key={r.id}
                className={`request-row${r.id === selectedId ? ' active' : ''}`}
                onClick={() => setSelectedId(r.id)}
              >
                <div>
                  <div className="r-name">{r.name}</div>
                  <div className="r-meta">
                    {r.email} ·{' '}
                    {new Date(r.created).toLocaleDateString('en-GB', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                    })}
                  </div>
                </div>
                <span className={`status-pill ${r.status || 'pending'}`}>
                  {r.status === 'confirmed'
                    ? 'Real & Approved'
                    : r.status === 'not_confirmed'
                    ? 'Counterfeit'
                    : (r.status || 'pending').replace('_', ' ')}
                </span>
              </button>
            ))
          )}
        </div>

        {selected ? (
          <RequestDetail key={selected.id} request={selected} onUpdate={records.update} />
        ) : (
          <div className="admin-detail">
            <p className="admin-empty">Select a request from the list to review and respond.</p>
          </div>
        )}
      </div>
    </main>
  );
}
