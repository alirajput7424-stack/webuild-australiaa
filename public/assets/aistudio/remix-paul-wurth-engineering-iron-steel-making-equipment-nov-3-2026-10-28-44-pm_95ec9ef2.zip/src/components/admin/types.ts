import type { RecordModel } from '@/lib/pocketbase-client';

export type VerificationRequest = RecordModel & {
  name: string;
  email: string;
  document: string;
  context: string;
  consent: boolean;
  status: 'confirmed' | 'pending' | 'not_confirmed' | 'needs_information' | string;
  response: string;
  reply_sent: boolean;
  refCode?: string;
  certificateId?: string;
  verifiedAt?: string;
  decisionLabel?: string;
  jobTitle?: string;
  secretKey?: string;
};
