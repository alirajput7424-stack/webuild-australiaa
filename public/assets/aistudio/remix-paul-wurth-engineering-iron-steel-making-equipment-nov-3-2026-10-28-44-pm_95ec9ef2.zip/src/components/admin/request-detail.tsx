import { useState } from 'react';
import { FileText, Send, CheckCircle2, ShieldCheck, AlertTriangle, Clock, ExternalLink, KeyRound, Copy } from 'lucide-react';
import pb from '@/lib/pocketbase-client';
import type { VerificationRequest } from '@/components/admin/types';

type Props = {
  request: VerificationRequest;
  onUpdate: (id: string, data: Record<string, unknown>) => Promise<unknown>;
};

const STATUSES = [
  { value: 'confirmed', label: 'Real & Officially Approved' },
  { value: 'pending', label: 'Pending Review' },
  { value: 'not_confirmed', label: 'Counterfeit / Fake Alert' },
  { value: 'needs_information', label: 'Needs More Information' },
];

export function RequestDetail({ request, onUpdate }: Props) {
  const [status, setStatus] = useState(request.status || 'pending');
  const [response, setResponse] = useState(request.response || '');
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');

  async function openDocument() {
    try {
      const url = pb.files.getUrl(request, request.document);
      window.open(url, '_blank');
    } catch {
      setError('Could not open the document. Please try again.');
    }
  }

  function applyQuickTemplate(newStatus: 'confirmed' | 'not_confirmed' | 'pending') {
    setStatus(newStatus);
    setDone(false);
    if (newStatus === 'confirmed') {
      setResponse(
        `Paul Wurth Geprolux HR Directorate has authenticated this offer letter for ${request.name}. The position details, official corporate seal, and employment terms correspond to authentic recruitment records registered at our Hollerich, Luxembourg headquarters. The offer letter is REAL & OFFICIALLY APPROVED.`
      );
    } else if (newStatus === 'not_confirmed') {
      setResponse(
        `FRAUD WARNING: The submitted document was NOT issued by Paul Wurth Geprolux S.A. or SMS group. Paul Wurth never charges applicants any fees, visa expenses, or training deposits. Do not remit any funds.`
      );
    } else {
      setResponse(
        `This document is currently under active manual verification by the recruitment committee at our Hollerich, Luxembourg headquarters.`
      );
    }
  }

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    setError('');
    setDone(false);
    try {
      await onUpdate(request.id, {
        status,
        response,
        reply_sent: true,
        verifiedAt: new Date().toISOString(),
      });
      setDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not send response.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="admin-detail">
      <h2>{request.name}</h2>
      <div className="detail-meta">
        {request.email} · Submitted{' '}
        {new Date(request.created).toLocaleDateString('en-GB', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        })}
      </div>

      <div className="detail-block">
        <h3>Job-letter document</h3>
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' }}>
          <button type="button" className="doc-link" onClick={openDocument}>
            <FileText size={15} /> Open PDF ({request.document})
          </button>
          <a
            href={`/#/verify`}
            target="_blank"
            rel="noopener noreferrer"
            style={{
              fontSize: '11px',
              color: 'var(--forest)',
              textDecoration: 'underline',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '4px',
            }}
          >
            Check on Verify portal <ExternalLink size={12} />
          </a>
        </div>
      </div>

      {/* 10-Digit Secret Verification Key for Consultants / Agency */}
      <div
        style={{
          marginTop: '16px',
          padding: '14px 16px',
          background: '#eff6ff',
          border: '1.5px solid #3b82f6',
          borderRadius: '6px',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#1e40af', fontWeight: 700, fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.6px' }}>
          <KeyRound size={14} />
          <span>10-Digit Secret Key (Send to Default Agency / Consultant):</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '8px', flexWrap: 'wrap', gap: '8px' }}>
          <strong style={{ fontSize: '20px', fontFamily: 'monospace', letterSpacing: '3px', color: '#1e3a8a' }}>
            {request.secretKey || '9482017365'}
          </strong>
          <button
            type="button"
            onClick={() => {
              navigator.clipboard.writeText(request.secretKey || '9482017365');
              alert(`Copied 10-digit key: ${request.secretKey || '9482017365'}`);
            }}
            style={{
              padding: '6px 12px',
              background: '#1d352c',
              color: '#ffffff',
              border: 'none',
              borderRadius: '4px',
              fontSize: '11px',
              fontWeight: 600,
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '4px',
            }}
          >
            <Copy size={13} /> Copy 10-Digit Key
          </button>
        </div>
        <p style={{ fontSize: '11px', color: '#3b82f6', marginTop: '6px' }}>
          Provide this 10-digit code to the default agency. When the candidate enters this code, they see their official verified status.
        </p>
      </div>

      {request.context && (
        <div className="detail-block">
          <h3>Context provided by applicant</h3>
          <p>{request.context}</p>
        </div>
      )}

      {/* Quick Status Action Presets */}
      <div style={{ marginTop: '20px', padding: '16px', background: 'var(--stone)', border: '1px solid var(--line)', borderRadius: '6px' }}>
        <strong style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.8px', color: 'var(--quiet)' }}>
          1-Click Quick Decision Presets:
        </strong>
        <div style={{ display: 'flex', gap: '8px', marginTop: '10px', flexWrap: 'wrap' }}>
          <button
            type="button"
            onClick={() => applyQuickTemplate('confirmed')}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              padding: '8px 12px',
              background: '#d1fae5',
              color: '#065f46',
              border: '1px solid #10b981',
              borderRadius: '4px',
              fontSize: '11px',
              fontWeight: 700,
              cursor: 'pointer',
            }}
          >
            <ShieldCheck size={14} /> Mark as Real & Approved
          </button>

          <button
            type="button"
            onClick={() => applyQuickTemplate('not_confirmed')}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              padding: '8px 12px',
              background: '#fee2e2',
              color: '#991b1b',
              border: '1px solid #ef4444',
              borderRadius: '4px',
              fontSize: '11px',
              fontWeight: 700,
              cursor: 'pointer',
            }}
          >
            <AlertTriangle size={14} /> Flag as Fake / Counterfeit
          </button>

          <button
            type="button"
            onClick={() => applyQuickTemplate('pending')}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              padding: '8px 12px',
              background: '#ffffff',
              color: '#4b5563',
              border: '1px solid #d1d5db',
              borderRadius: '4px',
              fontSize: '11px',
              fontWeight: 600,
              cursor: 'pointer',
            }}
          >
            <Clock size={14} /> Set Under Review
          </button>
        </div>
      </div>

      <form className="detail-form" onSubmit={submit} style={{ marginTop: '20px' }}>
        <label>
          Verification decision
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            {STATUSES.map((s) => (
              <option key={s.value} value={s.value}>
                {s.label}
              </option>
            ))}
          </select>
        </label>
        <label>
          Response / Certificate Statement
          <textarea
            rows={4}
            value={response}
            onChange={(e) => setResponse(e.target.value)}
            placeholder="Write the reply and certificate verification text…"
          />
        </label>
        {done && (
          <p className="reply-status" style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#059669', fontWeight: 600 }}>
            <CheckCircle2 size={15} /> Status updated to &ldquo;{status}&rdquo; — reflected on candidate&rsquo;s certificate!
          </p>
        )}
        {request.reply_sent && !done && (
          <p className="reply-status">A decision has been recorded for this applicant.</p>
        )}
        {error && <p className="form-error">{error}</p>}
        <button
          type="submit"
          className="solid-button"
          style={{ marginTop: 18 }}
          disabled={saving || !response.trim()}
        >
          {saving ? 'Saving changes…' : 'Save & Publish Decision'} <Send size={16} />
        </button>
      </form>
    </div>
  );
}
