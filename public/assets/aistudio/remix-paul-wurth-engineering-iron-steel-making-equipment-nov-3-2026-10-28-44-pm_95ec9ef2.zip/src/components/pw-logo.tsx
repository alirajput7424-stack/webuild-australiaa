interface PWLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl' | number;
  className?: string;
  styleVariant?: 'geometric' | 'shield' | 'minimal' | 'forge';
}

export function PWLogo({
  size = 'md',
  className = '',
  styleVariant = 'geometric',
}: PWLogoProps) {
  const pixelSize =
    typeof size === 'number'
      ? size
      : {
          sm: 34,
          md: 44,
          lg: 54,
          xl: 68,
        }[size];

  // STYLE 1: Geometric Architectural Interlocking PW (Bold, iconic, engineering-grade)
  if (styleVariant === 'geometric') {
    return (
      <svg
        width={pixelSize}
        height={pixelSize}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`select-none transition-transform duration-300 hover:scale-105 ${className}`}
        aria-label="Paul Wurth PW Logo"
      >
        <defs>
          {/* Cobalt Blue Gradient for the "P" */}
          <linearGradient id="pw-blue-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#004b87" />
            <stop offset="50%" stopColor="#0072ce" />
            <stop offset="100%" stopColor="#0094ff" />
          </linearGradient>

          {/* Precision Red / Ember Gradient for the "W" accent */}
          <linearGradient id="pw-red-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#b3000d" />
            <stop offset="60%" stopColor="#e30613" />
            <stop offset="100%" stopColor="#ff4040" />
          </linearGradient>

          {/* Platinum Industrial Sheen */}
          <linearGradient id="pw-metal-grad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#f8fafc" />
            <stop offset="100%" stopColor="#cbd5e1" />
          </linearGradient>

          {/* Drop shadow for architectural depth */}
          <filter id="pw-depth" x="-15%" y="-15%" width="130%" height="130%">
            <feDropShadow dx="0" dy="3" stdDeviation="3" floodColor="#000000" floodOpacity="0.22" />
          </filter>
        </defs>

        {/* Squircle Badge Background */}
        <rect
          x="3"
          y="3"
          width="94"
          height="94"
          rx="22"
          fill="#131c22"
          stroke="rgba(255, 255, 255, 0.12)"
          strokeWidth="2"
          filter="url(#pw-depth)"
        />

        {/* Subtle Background Structural Grid lines */}
        <path
          d="M18 50H82M50 18V82"
          stroke="rgba(255, 255, 255, 0.05)"
          strokeWidth="1.5"
          strokeDasharray="3 3"
        />

        {/* === The Letter "P" (Precision Engineered) === */}
        {/* Main P Vertical Stem */}
        <path
          d="M24 22H37V78H24V22Z"
          fill="url(#pw-blue-grad)"
        />

        {/* P Upper Loop */}
        <path
          d="M37 22H55C63.8366 22 71 29.1634 71 38C71 46.8366 63.8366 54 55 54H37V22ZM37 43.5H53.5C56.5376 43.5 59 41.0376 59 38C59 34.9624 56.5376 32.5 53.5 32.5H37V43.5Z"
          fill="url(#pw-blue-grad)"
        />

        {/* Stem Chamfer Highlight */}
        <path
          d="M24 22L32 16H37V22H24Z"
          fill="#0094ff"
          opacity="0.6"
        />

        {/* === The Letter "W" (Dynamic Interlocking Truss) === */}
        {/* First Diagonal of W (interlocks behind P loop) */}
        <path
          d="M44 48L53 78H63L52 48H44Z"
          fill="#ffffff"
          opacity="0.95"
        />

        {/* Center Peak of W */}
        <path
          d="M58 78L68 46H77L67 78H58Z"
          fill="#ffffff"
          opacity="0.9"
        />

        {/* Bold Red Forward Dynamic Wing of W */}
        <path
          d="M72 46L63 78H74L83 46H72Z"
          fill="url(#pw-red-grad)"
        />

        {/* Precision Arrow Tip on Final Apex */}
        <polygon
          points="83,46 76,46 80,38"
          fill="url(#pw-red-grad)"
        />

        {/* Center Precision Spark Emblem */}
        <circle cx="50" cy="50" r="2.5" fill="#bed3c3" />
      </svg>
    );
  }

  // STYLE 2: Shield / Hexagonal Industrial Crest
  if (styleVariant === 'shield') {
    return (
      <svg
        width={pixelSize}
        height={pixelSize}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`select-none transition-transform duration-300 hover:scale-105 ${className}`}
        aria-label="Paul Wurth Shield Logo"
      >
        <defs>
          <linearGradient id="shield-bg" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1a2b25" />
            <stop offset="100%" stopColor="#0d1713" />
          </linearGradient>
          <linearGradient id="shield-rim" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#008cda" />
            <stop offset="50%" stopColor="#bed3c3" />
            <stop offset="100%" stopColor="#e30613" />
          </linearGradient>
        </defs>

        {/* Hexagon Hull */}
        <polygon
          points="50,4 92,26 92,74 50,96 8,74 8,26"
          fill="url(#shield-bg)"
          stroke="url(#shield-rim)"
          strokeWidth="3"
        />

        {/* Inner Facet */}
        <polygon
          points="50,12 84,30 84,70 50,88 16,70 16,30"
          fill="none"
          stroke="rgba(255, 255, 255, 0.12)"
          strokeWidth="1.5"
        />

        {/* Monogram P */}
        <path
          d="M26 30H46C53 30 58 35 58 42C58 49 53 54 46 54H36V70H26V30ZM36 46H44C47 46 49 44 49 42C49 40 47 38 44 38H36V46Z"
          fill="#008cda"
        />

        {/* Monogram W */}
        <path
          d="M48 48L55 70H63L70 48H62L58 62L54 48H48Z"
          fill="#e30613"
        />
        <path
          d="M62 48L66 62L74 48H82L73 70H65L62 48Z"
          fill="#ffffff"
        />
      </svg>
    );
  }

  // STYLE 3: Minimalist Modernist Twin-Ribbon PW
  return (
    <svg
      width={pixelSize}
      height={pixelSize}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`select-none transition-transform duration-300 hover:scale-105 ${className}`}
      aria-label="Paul Wurth Minimalist Logo"
    >
      <rect width="100" height="100" rx="16" fill="#005ea6" />
      {/* Sleek bold P */}
      <path
        d="M22 24H48C57 24 64 31 64 40C64 49 57 56 48 56H34V76H22V24ZM34 44H46C50 44 52 42 52 40C52 38 50 36 46 36H34V44Z"
        fill="#ffffff"
      />
      {/* Dynamic Red W Accent */}
      <path
        d="M50 54L58 76H68L78 50H68L63 65L58 54H50Z"
        fill="#e30613"
      />
    </svg>
  );
}
