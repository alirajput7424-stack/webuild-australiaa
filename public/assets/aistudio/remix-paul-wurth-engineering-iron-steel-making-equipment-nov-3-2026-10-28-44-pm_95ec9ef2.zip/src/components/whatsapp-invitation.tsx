import { MessageLogo } from '@/components/message-logo';
import { officialGmailUrl } from '@/lib/contact-links';
import { officialEmail } from '@/data/site';
import { ArrowUpRight } from 'lucide-react';

export function WhatsAppInvitation() {
  return (
    <a
      href={officialGmailUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="email-float-launcher group"
      aria-label={`Email us on Gmail at ${officialEmail}`}
      title={`Open Gmail and contact us at ${officialEmail}`}
      style={{
        position: 'fixed',
        right: '24px',
        bottom: '24px',
        zIndex: 40,
        display: 'inline-flex',
        alignItems: 'center',
        gap: '10px',
        height: '52px',
        padding: '5px 18px 5px 6px',
        borderRadius: '30px',
        background: 'linear-gradient(135deg, #1d352c 0%, #15261f 100%)',
        color: '#ffffff',
        border: '1.5px solid rgba(190, 211, 195, 0.45)',
        boxShadow: '0 8px 24px rgba(29, 53, 44, 0.35)',
        textDecoration: 'none',
        cursor: 'pointer',
        transition: 'all 0.25s cubic-bezier(0.16, 1, 0.3, 1)',
      }}
    >
      <MessageLogo size="sm" withPulse />
      <div style={{ display: 'flex', flexDirection: 'column', textAlign: 'left' }}>
        <span
          style={{
            fontSize: '12.5px',
            fontWeight: 700,
            fontFamily: 'Manrope, sans-serif',
            letterSpacing: '0.2px',
            lineHeight: 1.15,
            color: '#ffffff',
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
          }}
        >
          Email us
          <ArrowUpRight size={13} style={{ opacity: 0.8 }} />
        </span>
        <span
          style={{
            fontSize: '9.5px',
            fontFamily: 'monospace',
            color: '#bed3c3',
            letterSpacing: '0.4px',
          }}
        >
          Gmail Compose
        </span>
      </div>
    </a>
  );
}
