export function siteOrigin(_request?: unknown): string {
  if (typeof window !== 'undefined') {
    return window.location.origin;
  }
  return '';
}
