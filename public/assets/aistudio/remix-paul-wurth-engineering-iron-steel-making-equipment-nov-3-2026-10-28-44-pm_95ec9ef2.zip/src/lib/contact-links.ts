const digitsOnly = (value: string) => value.replace(/\D/g, '');

export const telHref = (phone: string): string => {
  const isInternational = phone.trim().startsWith('+');
  return `tel:${isInternational ? '+' : ''}${digitsOnly(phone)}`;
};

export const mailtoHref = ({ email, subject, body }: { email: string; subject?: string; body?: string }): string => {
  const params = [
    subject && `subject=${encodeURIComponent(subject)}`,
    body && `body=${encodeURIComponent(body)}`,
  ].filter(Boolean);
  return `mailto:${email}${params.length ? `?${params.join('&')}` : ''}`;
};

export const whatsappUrl = ({ phone, text }: { phone: string; text?: string }): string =>
  `https://wa.me/${digitsOnly(phone)}${text ? `?text=${encodeURIComponent(text)}` : ''}`;

export const companyGoogleMapsUrl = 'https://maps.app.goo.gl/nLLcfjfTb5vJA96A8';

export const mapsUrl = ({ query }: { query?: string } = {}): string =>
  query ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}` : companyGoogleMapsUrl;

export const gmailComposeUrl = ({
  email = 'Info@paulwurthgeprolux.com',
  subject = 'Inquiry to Paul Wurth Geprolux',
}: {
  email?: string;
  subject?: string;
} = {}): string => {
  const params = new URLSearchParams();
  params.set('view', 'cm');
  params.set('fs', '1');
  params.set('to', email);
  if (subject) params.set('su', subject);
  return `https://mail.google.com/mail/?${params.toString()}`;
};

export const officialGmailUrl = gmailComposeUrl();
