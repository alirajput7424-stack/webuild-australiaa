import pb from '@/lib/pocketbase-client';

export function requireAuth(redirectTo = '/login') {
  const { record } = pb.authStore;
  if (!pb.authStore.isValid || !record) {
    if (typeof window !== 'undefined') {
      window.location.hash = redirectTo;
    }
    return null;
  }
  return record;
}

export default requireAuth;
