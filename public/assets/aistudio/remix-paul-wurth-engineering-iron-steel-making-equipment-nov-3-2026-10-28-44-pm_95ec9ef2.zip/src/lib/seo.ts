export type SeoInput = {
  title: string;
  description: string;
  path?: string;
  image?: string;
  type?: 'website' | 'article';
  noindex?: boolean;
  jsonLd?: object | object[];
};

export function updatePageSeo(input: SeoInput) {
  if (typeof document === 'undefined') return;
  document.title = input.title;

  const setMeta = (attrName: string, attrVal: string, content: string) => {
    let elem = document.querySelector(`meta[${attrName}="${attrVal}"]`);
    if (!elem) {
      elem = document.createElement('meta');
      elem.setAttribute(attrName, attrVal);
      document.head.appendChild(elem);
    }
    elem.setAttribute('content', content);
  };

  setMeta('name', 'description', input.description);
  setMeta('property', 'og:title', input.title);
  setMeta('property', 'og:description', input.description);
  if (input.image) {
    setMeta('property', 'og:image', input.image);
    setMeta('name', 'twitter:image', input.image);
  }
}
