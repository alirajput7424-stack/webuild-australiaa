import { useEffect, useMemo, useState } from 'react';
import pb, { type AuthRecord } from '@/lib/pocketbase-client';

export function useAuth() {
  const [user, setUser] = useState<AuthRecord | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setUser(pb.authStore.record);
    setIsLoading(false);
    return pb.authStore.onChange((_token, record) => setUser(record));
  }, []);

  return useMemo(
    () => ({
      user,
      isAuthed: Boolean(user),
      isLoading,
      login: (email: string, password: string) =>
        pb.collection('users').authWithPassword(email, password),
      logout: () => pb.authStore.clear(),
    }),
    [user, isLoading]
  );
}

export default useAuth;
