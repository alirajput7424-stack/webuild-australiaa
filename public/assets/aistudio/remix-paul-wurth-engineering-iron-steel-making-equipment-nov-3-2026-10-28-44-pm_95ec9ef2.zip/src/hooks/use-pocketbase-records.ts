import { useCallback, useEffect, useRef, useState } from 'react';
import pb, { type RecordModel, type RecordSubscription } from '@/lib/pocketbase-client';

type RecordsOptions = {
  sort?: string;
  filter?: string;
  expand?: string;
  perPage?: number;
  realtime?: boolean;
  enabled?: boolean;
};

type RecordData = FormData | Record<string, unknown>;
const NO_CANCEL = { requestKey: null };

export function usePocketbaseRecords<T extends RecordModel = RecordModel>(
  collection: string,
  { sort, filter, expand, perPage, realtime = false, enabled = true }: RecordsOptions = {}
) {
  const [records, setRecords] = useState<T[]>([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalItems, setTotalItems] = useState(0);
  const [isLoading, setIsLoading] = useState(enabled);
  const [error, setError] = useState<unknown>(null);
  const request = useRef(0);

  const load = useCallback(async () => {
    if (!enabled) {
      setRecords([]);
      setIsLoading(false);
      return;
    }
    const current = ++request.current;
    const query = { sort, filter, expand };
    setIsLoading(true);
    setError(null);
    try {
      if (perPage) {
        const result = await pb.collection<T>(collection).getList(page, perPage, query);
        if (current === request.current) {
          setRecords(result.items as T[]);
          setTotalPages(result.totalPages);
          setTotalItems(result.totalItems);
        }
      } else {
        const items = await pb.collection<T>(collection).getFullList(query);
        if (current === request.current) {
          setRecords(items as T[]);
          setTotalPages(1);
          setTotalItems(items.length);
        }
      }
    } catch (loadError) {
      if (current === request.current) {
        setError(loadError);
      }
    } finally {
      if (current === request.current) {
        setIsLoading(false);
      }
    }
  }, [collection, sort, filter, expand, perPage, page, enabled]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (!realtime || !enabled) {
      return;
    }

    const subscriptionPromise = pb.collection<T>(collection).subscribe(
      '*',
      (event: RecordSubscription<T>) => {
        if (event.action === 'create') {
          void load();
        } else if (event.action === 'update') {
          setRecords((current) =>
            current.map((record) => (record.id === event.record.id ? event.record : record))
          );
        } else if (event.action === 'delete') {
          setRecords((current) => current.filter((record) => record.id !== event.record.id));
        }
      }
    );

    return () => {
      void subscriptionPromise.then((unsubscribe) => unsubscribe && unsubscribe()).catch(() => {});
    };
  }, [collection, realtime, enabled, load]);

  const create = useCallback(
    async (data: RecordData) => {
      const record = await pb.collection<T>(collection).create(data, NO_CANCEL);
      await load();
      return record;
    },
    [collection, load]
  );

  const update = useCallback(
    async (id: string, data: RecordData) => {
      const record = await pb.collection<T>(collection).update(id, data, NO_CANCEL);
      setRecords((current) => current.map((item) => (item.id === id ? record : item)));
      return record;
    },
    [collection]
  );

  const remove = useCallback(
    async (id: string) => {
      await pb.collection(collection).delete(id, NO_CANCEL);
      setRecords((current) => current.filter((item) => item.id !== id));
      setTotalItems((current) => Math.max(0, current - 1));
    },
    [collection]
  );

  return {
    records,
    isLoading,
    error,
    reload: load,
    page,
    setPage,
    totalPages,
    totalItems,
    create,
    update,
    remove,
  };
}
