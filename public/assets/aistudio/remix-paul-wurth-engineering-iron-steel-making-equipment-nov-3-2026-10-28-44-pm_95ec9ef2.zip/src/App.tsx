import { useEffect } from 'react';
import { HashRouter, Routes, Route, useLocation } from 'react-router-dom';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';
import { CookieBanner } from '@/components/cookie-banner';
import { WhatsAppInvitation } from '@/components/whatsapp-invitation';

import HomePage from '@/routes/home';
import VerifyPage from '@/routes/verify';
import CareersPage from '@/routes/careers';
import LoginPage from '@/routes/login';
import AdminPage from '@/routes/admin';
import QrPage from '@/routes/qr';
import ProfilePage from '@/routes/profile';

function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

export default function App() {
  return (
    <HashRouter>
      <ScrollToTop />
      <a className="skip-link" href="#main-content">
        Skip to content
      </a>
      <SiteHeader />
      <div id="main-content">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/verify" element={<VerifyPage />} />
          <Route path="/careers" element={<CareersPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/admin" element={<AdminPage />} />
          <Route path="/qr" element={<QrPage />} />
          <Route path="/:page" element={<ProfilePage />} />
        </Routes>
      </div>
      <WhatsAppInvitation />
      <SiteFooter />
      <CookieBanner />
    </HashRouter>
  );
}
