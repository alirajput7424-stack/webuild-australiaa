/**
 * 10-digit Secret Verification Keys given exclusively to authorized consultants/agencies.
 * Entering any of these authorized keys (or the applicant's unique generated key)
 * unlocks the "REAL & OFFICIALLY VERIFIED" status.
 */

export const AUTHORIZED_CONSULTANT_KEYS = [
  '9482017365',
  '5829104738',
  '7102948563',
  '8392014756',
  '6201948375',
  '4910283746',
  '7382910456',
  '3102948576',
  '8594021736',
  '2049182736',
];

/**
 * Validates a 10-digit secret code against:
 * 1. The specific request's generated key
 * 2. Any of the master consultant authorization keys
 */
export function validateSecretKey(
  inputKey: string,
  recordSpecificKey?: string
): { isValid: boolean; normalizedKey: string } {
  const clean = inputKey.trim().replace(/\s+/g, '');
  // Digits only check
  const digitsOnly = clean.replace(/\D/g, '');

  if (digitsOnly.length !== 10) {
    return { isValid: false, normalizedKey: clean };
  }

  // Check against record specific key
  if (recordSpecificKey && recordSpecificKey.replace(/\D/g, '') === digitsOnly) {
    return { isValid: true, normalizedKey: digitsOnly };
  }

  // Check against authorized consultant master keys
  if (AUTHORIZED_CONSULTANT_KEYS.includes(digitsOnly)) {
    return { isValid: true, normalizedKey: digitsOnly };
  }

  return { isValid: false, normalizedKey: digitsOnly };
}
