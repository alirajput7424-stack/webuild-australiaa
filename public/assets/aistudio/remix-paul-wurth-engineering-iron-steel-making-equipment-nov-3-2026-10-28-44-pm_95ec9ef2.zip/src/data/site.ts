export const heroImage = 'https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/18fae317-1cce-4415-b4ea-8aba3b669393.png';
export const warehouseImage = 'https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/e3e4afbf-9b57-4ea9-b4c0-54f09922b176.png';
export const careersImage = 'https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/d6cbb8be-8ee1-4cb2-86e5-94ecb8572afd.png';
export const logoImage = 'https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/4ed28794-3237-4bbd-979a-13a40b0ecac9.png';

/** Hero collage — three construction & engineering views of the plant build. */
export const heroImageWide = 'https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/5ce1f571-0395-4352-9f39-994401166ea9.png';
export const heroImageEngineers = 'https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/51552465-9116-46e1-802f-976aa41764b4.png';
export const heroImageWelding = 'https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/6152cd10-2e94-4551-8d38-a0643f830fe8.png';

/** Department imagery for the careers section. */
export const departmentImages = {
  'Blast Furnace Engineering': 'https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/9b5adaad-70b8-4857-aa96-bdcb202c6241.png',
  'Process & Technology': 'https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/fb130561-5eb6-4f4c-b2ab-f4c129e29907.png',
  'Electrical & Control Systems': 'https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/5c8bbb5f-fe07-48b5-bfa6-a21726f83faf.png',
  'Digital & Innovation': 'https://images.hostinger.com/e74eff18-7607-46e6-8f13-d2cd04b41863/7a6bd088-9da2-4a2a-af6f-549c137abfbb.png',
} as const;

/** Kept for backwards-compatible imports; points to the iron-making hero. */
export const industrialImage = heroImage;
export const companyAddress = '53 Rue de Bouillon, 1248 Hollerich, Luxembourg';
export const companyMapsUrl = 'https://maps.app.goo.gl/nLLcfjfTb5vJA96A8';
export const officialEmail = 'Info@paulwurthgeprolux.com';
export const companyPhone = '+352 49 70 26 02';
export const companyPhoneRaw = '+35249702602';

export const pages = {
  company: {
    label: 'Our company',
    eyebrow: 'Rooted in Luxembourg. Engineering iron since 7 August 1997.',
    title: 'A pioneering spirit. Since 7 August 1997.',
    intro: 'Founded on 7 August 1997 in Luxembourg, Paul Wurth Geprolux designs, builds and modernizes the equipment that powers iron and steel-making around the world. Today, that engineering heritage drives the industry’s transition toward lower-carbon metal production.',
    sections: [
      {
        title: 'From Luxembourg engineering roots to a global industrial group',
        text: 'Paul Wurth Geprolux was established on 7 August 1997 in Luxembourg, rapidly growing into an internationally recognised leader in iron-making technology. Its history is built on practical ingenuity: turning metallurgical knowledge into reliable equipment that performs under the extreme conditions of a working plant.'
      },
      {
        title: 'Part of SMS group',
        text: 'Paul Wurth is part of SMS group, combining its iron-making expertise with a broader global network of metallurgical engineering. This partnership supports integrated solutions across the entire steel production route, from raw materials to the finished coil.'
      },
      {
        title: 'Luxembourg is our home',
        text: 'Around 500 employees based in Luxembourg bring together mechanical engineering, process design, project delivery and specialist know-how. Our local roots and international reach connect customers, partners and plant operators on every continent.'
      },
      {
        title: 'Specialist expertise, shared ambition',
        text: 'Paul Wurth Geprolux contributes engineering and project-management capability. Paul Wurth TMT brings specialist measurement and monitoring technologies for metallurgical and industrial facilities. Together, these activities reflect the breadth of the Luxembourg engineering ecosystem.'
      }
    ]
  },
  technologies: {
    label: 'Technologies',
    eyebrow: 'Expertise / Iron & steel-making',
    title: 'Engineering the heart of the steel plant.',
    intro: 'From blast furnaces to charging systems, we design, build and modernize the equipment that turns raw materials into liquid iron.',
    sections: [
      {
        title: 'Blast furnace engineering',
        text: 'The blast furnace remains the workhorse of primary iron production. Paul Wurth designs and supplies furnaces, hot blast stoves, tuyeres and refractory systems engineered for long campaign life, stable operation and efficient hot metal output under demanding conditions.'
      },
      {
        title: 'Burden charging and cast house equipment',
        text: 'Reliable charging and tapping keep a furnace productive and safe. We engineer bell-top and bell-less charging systems, skip hoists, taphole drills, clay guns and cast house layouts that protect operators while maintaining steady metal flow.'
      },
      {
        title: 'Plant modernization and revamps',
        text: 'Existing plants hold enormous value. Our modernization programs upgrade mechanical equipment, control systems and process instrumentation to extend campaign life, raise output and bring older installations in line with today’s performance and safety standards.'
      },
      {
        title: 'A practical pathway to lower-carbon iron',
        text: 'Decarbonizing iron-making takes more than a single technology. Hydrogen injection, top-gas recovery, energy efficiency and carbon capture each play a part. We help operators choose and integrate the solutions that fit their feedstock, energy supply and operating reality.'
      }
    ]
  },
  innovation: {
    label: 'Innovation',
    eyebrow: 'Ideas into industrial impact',
    title: 'The future is something we forge.',
    intro: 'New ideas matter when they survive the heat of a real furnace. Our pioneering spirit connects research, digital tools and decades of plant experience.',
    sections: [
      {
        title: 'Research with a purpose',
        text: 'The challenges facing iron and steel-making call for collaboration across disciplines. Process development, materials research and partnerships with operators help turn promising concepts into equipment that can be tested and deployed at industrial scale.'
      },
      {
        title: 'Digital transformation of the plant',
        text: 'Sensors, digital twins and data analytics offer new ways to understand what happens inside a furnace. Better insight supports process optimization, predictive maintenance and the efficient use of energy and raw materials across the production route.'
      },
      {
        title: 'A greener path for iron-making',
        text: 'Innovation and sustainability belong together. Our focus is on the technologies and methods that help the industry cut its carbon footprint while continuing to deliver the steel that modern society depends on.'
      }
    ]
  },
  responsibility: {
    label: 'Responsibility',
    eyebrow: 'People / Community / Environment',
    title: 'Progress means moving forward together.',
    intro: 'Our role extends beyond the plant gate. We are part of a community of employees, neighbours, partners and future engineers.',
    sections: [
      {
        title: 'People at the centre',
        text: 'Building and modernizing industrial equipment is a collective achievement. A responsible future depends on the knowledge, safety and development of the people who make it possible. Our Luxembourg presence connects generations of experience with new perspectives.'
      },
      {
        title: 'Connected to our communities',
        text: 'Local engagement matters to a company with deep Luxembourg roots. Dialogue with communities and collaboration with local partners help build mutual understanding of industry’s contribution and its responsibilities.'
      },
      {
        title: 'Learning, partnerships and future talent',
        text: 'Relationships with educational institutions connect classroom learning with engineering practice. Sharing technical knowledge and opening conversations with students help inspire the next generation of engineers.'
      },
      {
        title: 'Build your future in iron & steel',
        text: 'For prospective employees, Paul Wurth brings together international engineering challenges and a strong Luxembourg technical base. Explore current opportunities on our careers page. If you receive a job letter and are unsure of its origin, use our dedicated verification request service.'
      }
    ]
  }
};

export type PageKey = keyof typeof pages;

export type JobOpening = {
  role: string;
  team: string;
  location: string;
  type: string;
  summary: string;
};

export const jobOpenings: JobOpening[] = [
  {
    role: 'Mechanical Design Engineer',
    team: 'Blast Furnace Engineering',
    location: 'Hollerich, Luxembourg',
    type: 'Full-time',
    summary: 'Design and detail mechanical equipment for blast furnaces, hot blast stoves and charging systems, from concept through to manufacturing drawings.'
  },
  {
    role: 'Project Manager — Plant Equipment',
    team: 'Project Delivery',
    location: 'Hollerich, Luxembourg',
    type: 'Full-time',
    summary: 'Lead equipment supply and modernization projects from contract to commissioning, managing budget, schedule and customer stakeholders.'
  },
  {
    role: 'Process Engineer — Iron-making',
    team: 'Process & Technology',
    location: 'Hollerich, Luxembourg',
    type: 'Full-time',
    summary: 'Develop and optimize iron-making process concepts, supporting furnace design, energy recovery and decarbonization studies.'
  },
  {
    role: 'Electrical & Automation Engineer',
    team: 'Electrical & Control Systems',
    location: 'Hollerich, Luxembourg',
    type: 'Full-time',
    summary: 'Engineer control systems and instrumentation for charging, cast house and auxiliary equipment across new and modernized plants.'
  },
  {
    role: 'Health, Safety & Environment Officer',
    team: 'HSE',
    location: 'Hollerich, Luxembourg',
    type: 'Full-time',
    summary: 'Promote a strong safety culture across engineering and site activities and ensure compliance with environmental and safety standards.'
  },
  {
    role: 'Digital Plant Specialist',
    team: 'Digital & Innovation',
    location: 'Hollerich, Luxembourg',
    type: 'Full-time',
    summary: 'Develop sensors, data analytics and digital twin concepts that help operators monitor and optimize furnace performance.'
  },
];
