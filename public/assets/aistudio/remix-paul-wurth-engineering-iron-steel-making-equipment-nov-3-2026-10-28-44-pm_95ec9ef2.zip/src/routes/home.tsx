import { useEffect } from 'react';
import { Hero } from '@/components/home/hero';
import { Pioneering } from '@/components/home/pioneering';
import { Future } from '@/components/home/future';
import { WorkSites } from '@/components/home/work-sites';
import { Careers } from '@/components/home/careers';
import { WhatsAppInvitation } from '@/components/whatsapp-invitation';
import { updatePageSeo } from '@/lib/seo';
import { heroImage } from '@/data/site';

export default function HomePage() {
  useEffect(() => {
    updatePageSeo({
      title: 'Paul Wurth — Engineering iron & steel-making equipment',
      description:
        'Discover Paul Wurth in Luxembourg: established 7 August 1997, designing, building and modernizing equipment for the global iron and steel-making industry, pioneering lower-carbon iron production and digital plant innovation.',
      image: heroImage,
    });
  }, []);

  return (
    <main>
      <Hero />
      <Pioneering />
      <Future />
      <WorkSites />
      <Careers />
    </main>
  );
}
