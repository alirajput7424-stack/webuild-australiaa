import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/use-auth';
import { AdminDashboard } from '@/components/admin/admin-dashboard';
import { updatePageSeo } from '@/lib/seo';

export default function Admin() {
  const { user, isAuthed, isLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    updatePageSeo({
      title: 'Verification admin — Paul Wurth',
      description: 'Staff area for reviewing and responding to job-letter verification requests.',
      noindex: true,
    });
  }, []);

  useEffect(() => {
    if (!isLoading && !isAuthed) {
      navigate('/login', { replace: true });
    }
  }, [isAuthed, isLoading, navigate]);

  if (isLoading) {
    return (
      <main className="admin-page">
        <div className="admin-loading">Checking authorization…</div>
      </main>
    );
  }

  if (!isAuthed || !user) {
    return null;
  }

  return <AdminDashboard user={user} />;
}
