import { useEffect } from 'react';
import { CareersContent } from '@/components/careers-content';
import { updatePageSeo } from '@/lib/seo';
import { heroImage } from '@/data/site';

export default function Careers() {
  useEffect(() => {
    updatePageSeo({
      title: 'Careers — Paul Wurth',
      description:
        'Build your future with Paul Wurth in Luxembourg. Explore current openings in blast furnace engineering, process technology, electrical & automation and digital plant innovation, and learn how to apply.',
      image: heroImage,
    });
  }, []);

  return <CareersContent />;
}
