import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { updatePageSeo } from '@/lib/seo';

export default function Login() {
  const { login, isAuthed, isLoading } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    updatePageSeo({
      title: 'Staff sign in — Paul Wurth',
      description: 'Authorised staff sign in to manage job-letter verification requests.',
      noindex: true,
    });
  }, []);

  useEffect(() => {
    if (isAuthed) {
      navigate('/admin', { replace: true });
    }
  }, [isAuthed, navigate]);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      await login(email, password);
      navigate('/admin', { replace: true });
    } catch (err) {
      setError(
        err && typeof err === 'object' && 'status' in err && (err as { status?: number }).status === 400
          ? 'Invalid email or password.'
          : 'Could not sign in. Please try again.'
      );
    } finally {
      setSubmitting(false);
    }
  }

  if (isLoading) {
    return (
      <main className="auth-page">
        <div className="auth-panel">Loading session…</div>
      </main>
    );
  }

  return (
    <main className="auth-page">
      <form className="auth-panel" onSubmit={onSubmit}>
        <p className="eyebrow">
          <span></span>STAFF ACCESS
        </p>
        <h1>Sign in</h1>
        <p className="auth-note">
          Authorised staff only. Sign in to review job-letter verification requests and respond to applicants.
        </p>

        <label style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: '16px', fontSize: '12px' }}>
          Email address
          <input
            type="email"
            name="email"
            required
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{ width: '100%', border: '1px solid var(--line)', background: 'var(--stone)', padding: '12px' }}
          />
        </label>
        <label style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: '16px', fontSize: '12px' }}>
          Password
          <input
            type="password"
            name="password"
            required
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{ width: '100%', border: '1px solid var(--line)', background: 'var(--stone)', padding: '12px' }}
          />
        </label>
        {error && <p className="form-error">{error}</p>}
        <button
          type="submit"
          className="solid-button"
          style={{ marginTop: 24 }}
          disabled={submitting}
        >
          {submitting ? 'Signing in…' : 'Sign in'} <ArrowUpRight size={18} />
        </button>
      </form>
    </main>
  );
}
