import { useEffect } from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { pages, industrialImage, type PageKey } from '@/data/site';
import { EditorialContent } from '@/components/editorial-content';
import { updatePageSeo } from '@/lib/seo';

export default function Profile() {
  const { page } = useParams<{ page: string }>();

  if (!page || !Object.hasOwn(pages, page)) {
    return <Navigate to="/" replace />;
  }

  const pageKey = page as PageKey;
  const p = pages[pageKey];

  useEffect(() => {
    if (p) {
      updatePageSeo({
        title: `${p.label} — Paul Wurth`,
        description: p.intro,
        image: industrialImage,
      });
    }
  }, [p]);

  return <EditorialContent pageKey={pageKey} />;
}
