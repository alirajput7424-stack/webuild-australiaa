import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import QRCode from 'qrcode';
import { ArrowUpRight, Download, ExternalLink, ShieldCheck } from 'lucide-react';
import { updatePageSeo } from '@/lib/seo';
import { siteOrigin } from '@/lib/site-origin';

export function Qr() {
  const navigate = useNavigate();
  const [url, setUrl] = useState('');
  const [png, setPng] = useState('');
  const [svg, setSvg] = useState('');
  const [countdown, setCountdown] = useState<number | null>(null);

  useEffect(() => {
    updatePageSeo({
      title: 'Verification QR code — Paul Wurth',
      description: 'Scan or open to redirect to the Paul Wurth offer letter verification portal.',
      noindex: true,
    });

    const origin = typeof window !== 'undefined' && window.location.origin ? window.location.origin : siteOrigin();
    const targetUrl = `${origin}/#/verify`;
    setUrl(targetUrl);

    void QRCode.toDataURL(targetUrl, {
      margin: 1,
      width: 600,
      color: { dark: '#1d352c', light: '#ffffff' },
    }).then(setPng);

    void QRCode.toString(targetUrl, {
      type: 'svg',
      margin: 1,
      color: { dark: '#1d352c', light: '#ffffff' },
    }).then(setSvg);

    // If query contains ?redirect=1 or auto redirect is requested
    const params = new URLSearchParams(window.location.search);
    if (params.get('redirect') === '1' || params.get('auto') === '1') {
      setCountdown(2);
      const timer = setTimeout(() => {
        navigate('/verify');
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [navigate]);

  function downloadSvg() {
    if (!svg) return;
    const blob = new Blob([svg], { type: 'image/svg+xml' });
    const blobUrl = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = blobUrl;
    anchor.download = 'paulwurth-verification-portal-qr.svg';
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(blobUrl);
  }

  return (
    <main className="qr-page">
      <div className="qr-panel">
        <p className="eyebrow">
          <span></span>SCAN TO VERIFY
        </p>
        <h1>Offer letter verification QR</h1>
        <p>
          Scanning or opening this QR code redirects directly to the official Paul Wurth job offer verification portal, where candidates can submit their PDF and enter their 10-digit secret key.
        </p>

        {countdown !== null && (
          <div
            style={{
              padding: '10px 14px',
              background: '#ecfdf5',
              border: '1px solid #10b981',
              borderRadius: '6px',
              color: '#065f46',
              fontSize: '12px',
              margin: '14px 0',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}
          >
            <span>Redirecting to verification portal in {countdown}s…</span>
            <Link to="/verify" style={{ fontWeight: 700, textDecoration: 'underline' }}>
              Redirect now →
            </Link>
          </div>
        )}

        {/* Clickable QR Code linking directly to /verify */}
        <div style={{ position: 'relative', margin: '20px auto', width: 'fit-content' }}>
          <Link
            to="/verify"
            title="Click or tap to open the Offer Letter Verification Portal"
            className="qr-image group"
            style={{
              display: 'block',
              cursor: 'pointer',
              transition: 'transform 0.2s, box-shadow 0.2s',
              border: '2px solid #1d352c',
              borderRadius: '12px',
              padding: '12px',
              background: '#ffffff',
              boxShadow: '0 8px 24px rgba(29, 53, 44, 0.12)',
            }}
          >
            {png ? (
              <img
                src={png}
                alt="QR code linking directly to the Paul Wurth offer letter verification portal"
                width={260}
                height={260}
                style={{ display: 'block', borderRadius: '6px' }}
              />
            ) : (
              <div style={{ width: 260, height: 260, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                Generating QR…
              </div>
            )}
            <div
              style={{
                marginTop: '10px',
                textAlign: 'center',
                fontSize: '11px',
                fontWeight: 700,
                color: '#1d352c',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '4px',
              }}
            >
              <span>Click or scan to open verification portal</span>
              <ExternalLink size={12} />
            </div>
          </Link>
        </div>

        <p className="qr-url" style={{ wordBreak: 'break-all', textAlign: 'center' }}>
          {url}
        </p>

        {/* Primary CTA button to open verification portal directly */}
        <Link
          to="/verify"
          className="solid-button"
          style={{
            marginTop: '16px',
            textDecoration: 'none',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px',
          }}
        >
          <ShieldCheck size={18} />
          <span>Go to Offer Letter Verification Portal</span>
          <ArrowUpRight size={18} />
        </Link>

        {/* Downloads for print on offer letters */}
        <div className="qr-downloads" style={{ marginTop: '20px' }}>
          {png && (
            <a href={png} download="paulwurth-verification-portal-qr.png" style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
              <Download size={14} /> Download PNG
            </a>
          )}
          {svg && (
            <button type="button" onClick={downloadSvg} style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
              <Download size={14} /> Download SVG
            </button>
          )}
        </div>
      </div>
    </main>
  );
}

export default Qr;
