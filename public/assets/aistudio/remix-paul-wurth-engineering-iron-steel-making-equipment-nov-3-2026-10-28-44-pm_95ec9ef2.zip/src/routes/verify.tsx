import { useEffect } from 'react';
import { VerificationForm } from '@/components/verification-form';
import { updatePageSeo } from '@/lib/seo';
import { industrialImage } from '@/data/site';

export default function Verify() {
  useEffect(() => {
    updatePageSeo({
      title: 'Job-letter verification — Paul Wurth',
      description:
        'Request a manual review of a job letter claiming to be from Paul Wurth. Upload your PDF securely and receive a response by email after review.',
      image: industrialImage,
    });
  }, []);

  return <VerificationForm />;
}
